<?php

function resourcespace_sso_init(){
	
	add_settings_field('resourcespace_url',
			'ResourceSpace URL',
			'resourcespace_url_callback_function',
			'general',
			'default'
			);		
	
	register_setting( 'general', 'resourcespace_url' );

	add_settings_field('resourcespace_secret_key',
			'ResourceSpace shared key',
			'resourcespace_secret_key_callback_function',
			'general',
			'default'
			);		
	
	register_setting( 'general', 'resourcespace_secret_key' );			

}

add_action('admin_init', 'resourcespace_sso_init');


function resourcespace_url_callback_function() {
	echo '<p>Enter the ResourceSpace URL. This should be the same as the value for $baseurl in the ResourceSpace config.php</p>';
	echo '<input name="resourcespace_url" id="resourcespace_url" type="text" value="' . get_option('resourcespace_url') . '" size="100" class="text" /><br>';
	} 

function resourcespace_secret_key_callback_function() {
	echo '<p>Enter the shared secret key to allow authentication to the ResourceSpace system. This should match that set in the ResourceSpace wordpress-sso plugin configuration</p>';
	echo '<input name="resourcespace_secret_key" id="resourcespace_secret_key" type="text" class="text" size="100" value="' . get_option( 'resourcespace_secret_key' ) . '"/><br>';
	}