<?php
/*
Plugin Name: ResourceSpace SSO
Plugin URI: 
Description: Enables ResourceSpace to authenticate against WordPress
Version: 1.0.0
Author: Montala
Author URI: http://www.montala.com
*/



if (is_admin()) include( WP_PLUGIN_DIR . '/resourcespace-sso/admin.php' );


function rs_authenticate ()
	{
	if (isset($_GET['rsauth']))
		{
		$rs_url	= get_option( 'resourcespace_url' );
		$rs_key = get_option( 'resourcespace_secret_key' );
		$rs_requested_path='/';
		$requestid="";
		
		if (isset($_GET['url'])){$url=$_GET['url'];$rs_requested_path=$url;}
		if (isset($_GET['requestid'])){$requestid=$_GET['requestid'];}
		
		# fix for double encoded querystring after login
		if (isset($_GET['amp;url'])){$url=$_GET['amp;url'];$rs_requested_path=$url;} 
		if (isset($_GET['amp;requestid'])){$requestid=$_GET['amp;requestid'];}
		
		if (strpos($rs_requested_path,"?")!=false){$rs_requested_path.="&";} else {$rs_requested_path.="?";}
		
		global $current_user;
		$current_user = wp_get_current_user();	
		if ( 0 != $current_user->ID ) # check if logged in
			{
			$wpdetails="";if (isset($_GET['getdetails'])){$wpdetails = "|" . $current_user->user_email . "|" . $current_user->display_name ;}
			$clientip=$_SERVER['REMOTE_ADDR'];			
			$today = date("Ymd");		
			$username = $current_user->display_name;
			$password_hash=md5($rs_url . $rs_key . $username . $today);
			$request_hash=md5($rs_url . $rs_key . $username . $today . $requestid);
			$redirect_url=$rs_url . $rs_requested_path . "wordpress_sso_user=" . $username . "|" . $password_hash . "|" . $request_hash . $wpdetails . "&requestid=" . $requestid;
			header("Location: $redirect_url");
			}
		}
	}

add_action('init', 'rs_authenticate');
?>
