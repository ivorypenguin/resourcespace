﻿=== ResourceSpace Wordpress SSO ===
Contributors: montala
Donate link: 
Tags: login
Requires at least: 2.8
Tested up to: 4.4
Stable tag: 4.4

ResourceSpace SSO - enables ResourceSpace to authenticate against WordPress

== Description ==

ResourceSpace SSO - enables ResourceSpace to authenticate against WordPress

== Localization ==

Added localizations are listed below. 

== Installation ==

Add the plugin

== Frequently Asked Questions ==


   
= Configuration =


== Screenshots ==


== Changelog ==


